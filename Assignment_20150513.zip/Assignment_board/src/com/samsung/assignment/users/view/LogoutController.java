package com.samsung.assignment.users.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.assignment.controller.Controller;
/**
 * 로그아웃 컨트롤러
 * @author student
 *
 */
public class LogoutController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "getBoardList.do";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		return null;
	}
}
