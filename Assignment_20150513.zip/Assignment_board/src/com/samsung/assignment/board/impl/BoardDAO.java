package com.samsung.assignment.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.board.vo.Count_checkVO;
import com.samsung.assignment.utils.JDBCUtil;

public class BoardDAO {
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	/**
	 * 페이지 개수를 가져오는 메서드
	 * @return pages
	 */
	public int getPagingNum(){
		int result = 0;
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT COUNT(BOARD_SEQ) boards FROM BOARD";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			if(rs.next()){
				result = rs.getInt("boards");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return result;
	}
	
	/**
	 * 게시글 리스트 가져오는 메서드
	 * @param pageNum
	 * @return
	 */
	public ArrayList<BoardVO> list(int page, int interval) {
		ArrayList<BoardVO> boardList = new ArrayList<BoardVO>();

		StringBuilder q = new StringBuilder(100);
		q.append(" select b.*	                               ");
		q.append(" from ( select rownum ro, a.*	             ");
		q.append(" 	      from (select *  ");
		q.append(" 			       from board                       ");
		q.append(" 			       ORDER BY BOARD_PARENTSEQ DESC, BOARD_STEP ASC                  ");
		q.append(" 			       ) a                                ");
		q.append(" 	     ) b                                   ");
		q.append(" where ro>= ? and ro <= ?	                 ");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q.toString());
			int start = 1; 
			int end = interval; 
			if (page > 1) {
				start = (page - 1) * interval + 1;
				end = page * interval;
			}
			stmt.setInt(1, start);
			stmt.setInt(2, end);
			rs = stmt.executeQuery();
			while (rs.next()) {
				boardList.add(new BoardVO(rs.getInt("board_seq"), rs.getString("board_title"), "", rs.getString("user_id"), rs.getInt("board_cnt"), rs.getDate("board_regdate"), rs.getInt("board_parentSeq"), rs.getInt("board_step"), rs.getInt("board_lvl")));
			}
		} catch(SQLException e){
			e.printStackTrace();	
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return boardList;
	}
	/**
	 * 게시글 개수를 가져오는 메서드
	 * @return
	 */
	public int listCount() {
		int count = 0;
		String q = "select count(*) cnt from board";
		
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q);
			rs = stmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt("cnt");
			}
		} catch(SQLException e){
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return count;
	}
	/**
	 * 하나의 게시글을 가져오는 메서드
	 * @param vo
	 * @return
	 */
	public BoardVO getBoardView(BoardVO vo){
		BoardVO board = new BoardVO();
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT * FROM BOARD WHERE BOARD_SEQ = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			rs = stmt.executeQuery();
			if(rs.next()){
				board = new BoardVO(rs.getInt("board_seq"), rs.getString("board_title"), rs.getString("board_content"), rs.getString("user_id"), rs.getInt("board_cnt"), rs.getDate("board_regdate"), rs.getInt("board_parentSeq"), rs.getInt("board_step"), rs.getInt("board_lvl"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return board;
	}
	
	/**
	 * 게시글을 삽입하는 메서드
	 * '새글 쓰기'에만 적용됨
	 * @param vo
	 * @return
	 */
	public boolean insertNewBoard(BoardVO vo){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "INSERT INTO BOARD VALUES(BOARD_SEQ.NEXTVAL, ?, ?, ?, 0, SYSDATE, BOARD_SEQ.CURRVAL, 0, 0)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getUser_id());
			stmt.setString(2, vo.getBoard_title());
			stmt.setString(3, vo.getBoard_content());
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 답글을 삽입하는 메서드
	 * '답글 쓰기'에만 적용됨
	 * @param vo
	 * @return
	 */
	public BoardVO insertReplyBoard(BoardVO vo){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "INSERT INTO BOARD VALUES(BOARD_SEQ.NEXTVAL, ?, ?, ?, 0, SYSDATE, ?, ?, ?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getUser_id());
			stmt.setString(2, vo.getBoard_title());
			stmt.setString(3, vo.getBoard_content());
			stmt.setInt(4, vo.getBoard_parentSeq());
			stmt.setInt(5, vo.getBoard_step());
			stmt.setInt(6, vo.getBoard_lvl());
			int result = stmt.executeUpdate();
			if(result>0){
				sql = "SELECT * FROM BOARD WHERE BOARD_SEQ = (SELECT MAX(BOARD_SEQ) FROM BOARD)";
				stmt = conn.prepareStatement(sql);
				rs = stmt.executeQuery();
				if(rs.next()){
					return new BoardVO(rs.getInt("board_seq"), rs.getString("board_title"), rs.getString("board_content"), rs.getString("user_id"), rs.getInt("board_cnt"), rs.getDate("board_regdate"), rs.getInt("board_parentSeq"), rs.getInt("board_step"), rs.getInt("board_lvl"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return null;
	}
	
	/**
	 * 답글 작성 시 답글의 BOARD_Step을 1 증가시키기 위해 작성된 답글 목록 중 BOARD_Step을 리턴하는 함수 
	 * @param vo
	 * @return
	 */
	public int selectMaxStep(int board_parentSeq){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT BOARD_Step FROM BOARD WHERE BOARD_SEQ = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, board_parentSeq);
			rs = stmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return 0;
	}
	
	/**
	 * 중간에 답글이 달릴 경우 그 아래에 있던 답글들의 step을 +1시키는 메서드
	 * @param board_step
	 * @return
	 */
	public boolean updateStep(int board_parentSet, int board_step){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "UPDATE BOARD SET BOARD_Step=BOARD_STEP+1 WHERE BOARD_PARENTSEQ = ? AND BOARD_STEP > ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, board_parentSet);
			stmt.setInt(2, board_step);
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 답글 작성 시 윗 글의 LVL을 1 증가시키기 위해 BOARD_LVL을 리턴하는 함수
	 * @param board_seq
	 * @return
	 */
	public int selectLvl(int board_seq){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT BOARD_LVL FROM BOARD WHERE BOARD_SEQ = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, board_seq);
			rs = stmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return 0;
	}
	
	/**
	 * 답글 작성 시 가장 첫번째 글의 번호를 찾아서 리턴하는 메서드
	 * @param board_parentSeq
	 * @return
	 */
	public int selectBoardSeq(int board_parentSeq){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT BOARD_PARENTSEQ FROM BOARD WHERE BOARD_SEQ=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, board_parentSeq);
			rs = stmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return 0;
	}
	
	/**
	 * 게시글의 제목과 내용을 수정하는 메서드
	 * @param vo
	 * @return
	 */
	public boolean updateBoard(BoardVO vo){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "UPDATE BOARD SET BOARD_TITLE = ?, BOARD_CONTENT = ? WHERE BOARD_SEQ = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getBoard_title());
			stmt.setString(2, vo.getBoard_content());
			stmt.setInt(3, vo.getBoard_seq());
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 게시글을 삭제하기 전에 답글이 있는지 조회하는 메서드
	 * @param vo
	 * @return
	 */
	public boolean deleteCheckBoard(BoardVO vo){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT COUNT(BOARD_SEQ) FROM BOARD WHERE BOARD_PARENTSEQ = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			rs = stmt.executeQuery();
			if(rs.next()){
				if(rs.getInt(1)>1){
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return true;
	}
	
	/**
	 * 게시글을 삭제하는 메서드
	 * 데이터베이스에서 삭제시키지 않으며, 
	 * 제목을 '삭제된 글입니다'라고 update한 뒤 조회하지 못하도록 함
	 * @param vo
	 * @return
	 */
	public boolean deleteBoard(BoardVO vo){
		try {
			conn = JDBCUtil.getConnection();
			String sql = "UPDATE BOARD SET BOARD_TITLE='D' WHERE BOARD_SEQ=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 로그인한 사용자가 게시글을 조회했는지 확인하는 메서드
	 * @param user_id
	 * @return
	 */
	public Count_checkVO selectCountCheckToday(BoardVO vo) {
		Count_checkVO checkVO = new Count_checkVO();
		try {
			conn = JDBCUtil.getConnection();
			String sql = "SELECT * FROM COUNT_CHECK WHERE BOARD_SEQ = ? AND USER_ID = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			stmt.setString(2, vo.getUser_id());
			rs = stmt.executeQuery();
			if(rs.next()){
				checkVO = new Count_checkVO(rs.getInt("board_seq"), rs.getString("user_id"), rs.getDate("checkdate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt, rs);
		}
		return checkVO;
	}
	
	/**
	 * 사용자가 오늘 게시글을 조회했을 경우 해당 테이블에 조회했다는 데이터를 넣는 메서드
	 * @param user_id
	 * @return
	 */
	public boolean insertCountCheckToday(BoardVO vo) {
		try {
			conn = JDBCUtil.getConnection();
			String sql = "INSERT INTO COUNT_CHECK VALUES(?, ?, SYSDATE)";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			stmt.setString(2, vo.getUser_id());
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 사용자가 이전에 게시글을 조회한 이력이 있는 경우 날짜만 오늘로 바꾸기
	 * @param vo
	 * @return
	 */
	public boolean updateCount_CheckDate(BoardVO vo) {
		try {
			conn = JDBCUtil.getConnection();
			String sql = "UPDATE COUNT_CHECK SET CHECKDATE = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setDate(1, vo.getBoard_regdate());
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
		return false;
	}
	
	/**
	 * 조회수를 1 증가시키는 메서드
	 * @param vo
	 */
	public void updateBoardCnt(BoardVO vo) {
		try {
			conn = JDBCUtil.getConnection();
			String sql = "UPDATE BOARD SET BOARD_CNT = BOARD_CNT +1 WHERE BOARD_SEQ = ? ";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getBoard_seq());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JDBCUtil.close(conn, stmt);
		}
	}
	
	/**
	 * 제목으로 검색하는 메서드
	 * @param search
	 */
	public ArrayList<BoardVO> searchByTitle(String search, int page, int interval) {
		ArrayList<BoardVO> boardList = new ArrayList<BoardVO>();

		StringBuilder q = new StringBuilder(100);
		q.append(" select b.*	                               ");
		q.append(" from ( select rownum ro, a.*	             ");
		q.append(" 	      from (select *  ");
		q.append(" 			       from board                       ");
		q.append("					where board_title like '%"+search+"%'		");
		q.append(" 			       ORDER BY BOARD_PARENTSEQ DESC, BOARD_STEP ASC                  ");
		q.append(" 			       ) a                                ");
		q.append(" 	     ) b                                   ");
		q.append(" where ro>= ? and ro <= ?	                 ");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q.toString());
			int start = 1; 
			int end = interval; 
			if (page > 1) {
				start = (page - 1) * interval + 1;
				end = page * interval;
			}
			stmt.setInt(1, start);
			stmt.setInt(2, end);
			rs = stmt.executeQuery();
			while (rs.next()) {
				boardList.add(new BoardVO(rs.getInt("board_seq"), rs.getString("board_title"), "", rs.getString("user_id"), rs.getInt("board_cnt"), rs.getDate("board_regdate"), rs.getInt("board_parentSeq"), rs.getInt("board_step"), rs.getInt("board_lvl")));
			}
		} catch(SQLException e){
			e.printStackTrace();	
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return boardList;
	}
	
	public int searchByTitleCount(String title){
		int count = 0;
		String q = "select count(*) cnt from board where board_title like '%"+title+"%'";
		
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q);
			rs = stmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt("cnt");
			}
		} catch(SQLException e){
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return count;
	}
	
	/**
	 * 내용으로 검색하는 메서드
	 * @param search
	 * @return 
	 */
	public ArrayList<BoardVO> searchByContent(String search, int page, int interval) {
		ArrayList<BoardVO> boardList = new ArrayList<BoardVO>();

		StringBuilder q = new StringBuilder(100);
		q.append(" select b.*	                               ");
		q.append(" from ( select rownum ro, a.*	             ");
		q.append(" 	      from (select *  ");
		q.append(" 			       from board                       ");
		q.append("					where user_id like '%"+search+"%'		");
		q.append(" 			       ORDER BY BOARD_PARENTSEQ DESC, BOARD_STEP ASC                  ");
		q.append(" 			       ) a                                ");
		q.append(" 	     ) b                                   ");
		q.append(" where ro>= ? and ro <= ?	                 ");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q.toString());
			int start = 1; 
			int end = interval; 
			if (page > 1) {
				start = (page - 1) * interval + 1;
				end = page * interval;
			}
			stmt.setInt(1, start);
			stmt.setInt(2, end);
			rs = stmt.executeQuery();
			while (rs.next()) {
				boardList.add(new BoardVO(rs.getInt("board_seq"), rs.getString("board_title"), "", rs.getString("user_id"), rs.getInt("board_cnt"), rs.getDate("board_regdate"), rs.getInt("board_parentSeq"), rs.getInt("board_step"), rs.getInt("board_lvl")));
			}
		} catch(SQLException e){
			e.printStackTrace();	
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return boardList;
	}

	public int searchByContentCount(String search) {
		int count = 0;
		String q = "select count(*) cnt from board where user_id like '%"+search+"%'";
		
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(q);
			rs = stmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt("cnt");
			}
		} catch(SQLException e){
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return count;
	}
}
