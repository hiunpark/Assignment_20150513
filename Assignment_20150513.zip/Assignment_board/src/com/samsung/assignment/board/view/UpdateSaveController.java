package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.Controller;

public class UpdateSaveController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		String board_title = request.getParameter("board_title"); 
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		
		BoardDAO dao = new BoardDAO();
		boolean done = dao.updateBoard(vo);
		if(done){
			return done;
		}else{
			return done;
		}
	}

}
