package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.Controller;

public class InsertReplyController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		if(session.getAttribute("user_id")==null){
			request.setAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "getBoardList.do";
		}
		
		String user_id = (String) session.getAttribute("user_id");
		int board_grandParentSeq = Integer.parseInt(request.getParameter("board_grandParentSeq"));
		int board_parentSeq = Integer.parseInt(request.getParameter("board_parentSeq"));
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setUser_id(user_id);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		vo.setBoard_parentSeq(board_grandParentSeq);
		
		// step과 lvl을 가져와서 1씩 증가시키기
		BoardDAO dao = new BoardDAO();
		// 바로 윗글의 step을 가져오기
		int parentStep = dao.selectMaxStep(board_parentSeq);
		// 바로 윗글에 대한 lvl을 가져오기
		int parentLvl = dao.selectLvl(board_parentSeq);
		vo.setBoard_step(parentStep+1);
		vo.setBoard_lvl(parentLvl+1);
		
		// 새로 생성되는 답글들의 아래 답글들 step을 +1시키는 메서드
		boolean done = true;
		done = dao.updateStep(board_grandParentSeq, parentStep);
		BoardVO board = dao.insertReplyBoard(vo);
		// 삽입 완료 후 작성된 게시글 페이지로 이동
		if(board!=null && done){
			return "getBoardView.do?board_seq="+board.getBoard_seq();
		}else{
			request.setAttribute("msg", "답글 저장 중 에러 발생");
			request.setAttribute("writingBoard", vo);
			return "reply.jsp";
		}
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}
}
