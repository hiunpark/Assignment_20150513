package com.samsung.assignment.board.view;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.board.vo.Count_checkVO;
import com.samsung.assignment.controller.Controller;

public class GetBoardViewController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		// 게시글 가져오기
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoardView(vo);
		
		request.setAttribute("board", board);
		
		// 게시글 조회수 늘리기
		
		// 세션의 유저 정보 가져오기
		HttpSession session = request.getSession();
		String user_id = "";
		// 현재 날짜 가져오기
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date currentTime = new java.util.Date();
		String dTime = formatter.format(currentTime);
		java.sql.Date checkDate = java.sql.Date.valueOf(dTime);
		// 만약 로그인한 유저가 있다면
		if(session.getAttribute("user_id")!=null){
			user_id = (String)session.getAttribute("user_id");
			vo.setUser_id(user_id);
			// 1. count_check 테이블에 가서 사용자가 오늘 로그인한 뒤 게시글을 조회했는지 확인
			// 조회했으면 true, 조회하지 않았으면 false
			Count_checkVO checkVO = dao.selectCountCheckToday(vo);
			
			// 2-1. 만약 처음 조회한다면 count_check 테이블에 유저, 날짜를 집어넣고
			if(checkVO.getBoard_seq()==0){
				boolean done = dao.insertCountCheckToday(vo);
				// 2-2. 조회수를 1 증가시키기
				if(done){
					dao.updateBoardCnt(vo);
					return "boardView.jsp";
				}
			
				// 3-1. 만약 테이블에 데이터가 있으나 날짜가 같지 않을 경우 
			}else if(checkVO.getUser_id().equals(user_id)  && !checkDate.equals(checkVO.getCheckdate())){
				
				// 3-2. 테이블의 날짜 데이터를 오늘로 update하고
				vo.setBoard_regdate(checkDate);
				boolean done = dao.updateCount_CheckDate(vo);
				// 3-3. 조회수를 1 증가시키기
				if(done){
					dao.updateBoardCnt(vo);
					return "boardView.jsp";
				}
				// 4-1. 만약 테이블에 유저 정보와 오늘 날짜가 있다면
			}else if(checkVO.getUser_id().equals(user_id) /*날짜 오늘이면*/){
				// 조회수 증가시키지 않고 그냥 리턴
				return "boardView.jsp";
			}
			
		}
		// 만약 로그인한 유저가 없다면
		// 그 외에는 IP로 추적해야 하나...skip
		// 조회수만 증가
		dao.updateBoardCnt(vo);
		return "boardView.jsp";
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

}
