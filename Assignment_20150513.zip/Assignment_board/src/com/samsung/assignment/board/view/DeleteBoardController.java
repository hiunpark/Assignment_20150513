package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.Controller;

/**
 * 게시글을 삭제하기 위한 컨트롤러
 * 실제로 게시글을 삭제하지는 않으며, 제목을 '삭제된 글입니다'라고 update한 뒤 조회하지 못하도록 함
 * @author student
 *
 */
public class DeleteBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		
		BoardDAO dao = new BoardDAO();
		
		// 답글이 있는 글인지 조회
		boolean canDelete = dao.deleteCheckBoard(vo);
		if(canDelete){
			// 답글이 없으면 게시글 삭제
			boolean done = dao.deleteBoard(vo);
			if(done){
				request.setAttribute("msg", "삭제 완료");
				return "getBoardList.do";
			}else{
				request.setAttribute("msg", "삭제 도중 에러 발생!");
				request.setAttribute("board_seq", board_seq);
				return "getBoardView.do";
			}
		}else{
			// 답글이 있는 글이면 게시글 삭제하지 못하게 함
			request.setAttribute("msg", "답글이 있는 글은 삭제할 수 없습니다");
			request.setAttribute("board_seq", board_seq);
			return "getBoardView.do";
		}
	}

	@Override
	public Object jqueryRequest(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

}
